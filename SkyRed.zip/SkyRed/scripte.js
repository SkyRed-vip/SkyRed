document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const uniqueCode = document.getElementById("unique_code").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    if (uniqueCode && password) {
        alert(`مرحبًا! تم تسجيل الدخول كـ ${role}`);
    } else {
        document.getElementById("errorMsg").innerText = "يرجى ملء جميع الحقول!";
    }
});
